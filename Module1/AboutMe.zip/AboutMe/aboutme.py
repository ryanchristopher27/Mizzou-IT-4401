#About Me
#Ryan Christopher

print('Ryan Christopher')
print('I am currently a sophomore studying computer science.')
print('I am from Springfield, Missouri.')
print('My favorite sport is soccer and I have played my whole life.')
print('I am a member of Phi Delta Theta here at Mizzou.')
